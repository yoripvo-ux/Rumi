package com.rumi.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val purple = Color.rgb(105, 75, 160)
    private val requestAudio = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        addMessage("RUMI", "سلام! من رومی هستم. می‌تونی تایپ کنی یا دکمه میکروفون رو بزنی.")
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        }
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 244, 252))
            setPadding(20, 18, 20, 14)
        }

        val header = TextView(this).apply {
            text = "RUMI  ✦"
            textSize = 27f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 14)
        }
        page.addView(header)

        val subtitle = TextView(this).apply {
            text = "Your personal assistant"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        page.addView(subtitle)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.WHITE)
            setPadding(10, 10, 10, 10)
        }
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(chat)
        page.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 12, 0, 0)
        }
        input = EditText(this).apply {
            hint = "پیامت را بنویس..."
            textSize = 16f
            setSingleLine(true)
            setPadding(12, 8, 12, 8)
            background = roundedBackground(Color.WHITE)
        }
        controls.addView(input, LinearLayout.LayoutParams(0, 52, 1f))

        val send = Button(this).apply {
            text = "ارسال"
            setTextColor(Color.WHITE)
            background = roundedBackground(purple)
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) {
                    input.setText("")
                    hideKeyboard()
                    handleMessage(message)
                }
            }
        }
        controls.addView(send, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 52
        ).apply { setMargins(6, 0, 0, 0) })

        val mic = Button(this).apply {
            text = "🎙"
            contentDescription = "شروع فرمان صوتی"
            setOnClickListener { startListening() }
        }
        controls.addView(mic, LinearLayout.LayoutParams(58, 52).apply {
            setMargins(6, 0, 0, 0)
        })
        page.addView(controls)
        setContentView(page)
    }

    private fun roundedBackground(color: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = 22f
        }
    }

    private fun addMessage(sender: String, message: String) {
        val label = TextView(this).apply {
            text = sender
            textSize = 12f
            setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 10, 4, 2)
        }
        val body = TextView(this).apply {
            text = message
            textSize = 16f
            setTextColor(Color.rgb(40, 35, 48))
            setPadding(12, 10, 12, 10)
            background = roundedBackground(
                if (sender == "RUMI") Color.rgb(239, 233, 249) else Color.rgb(238, 242, 248)
            )
        }
        chat.addView(label)
        chat.addView(body)
    }

    private fun handleMessage(message: String) {
        addMessage("You", message)
        val answer = when {
            message.contains("سلام") || message.contains("hello", true) || message.contains("hi", true) ->
                "سلام! چطور می‌تونم کمکت کنم؟"
            message.contains("زمان") || message.contains("ساعت") ->
                "برای دیدن ساعت دقیق، ساعت گوشی‌ات را بررسی کن."
            message.contains("باز کن") || message.contains("open", true) ->
                openRequestedApp(message)
            message.contains("ترجمه") ->
                "فعلاً ترجمهٔ آفلاین در این نسخه فعال نیست. متن را بفرست تا در نسخهٔ بعدی قابلیت ترجمه را اضافه کنیم."
            message.contains("اسم") || message.contains("نام") ->
                "اسم من رومی است؛ دستیار شخصی تو."
            else ->
                "پیامت رو دریافت کردم. در این نسخه پاسخ‌ها ساده و آفلاین هستند؛ برای گفت‌وگوی هوشمند باید بعداً یک سرویس هوش مصنوعی امن به رومی وصل کنیم."
        }
        addMessage("RUMI", answer)
        speak(answer)
    }

    private fun openRequestedApp(message: String): String {
        val apps = listOf(
            "تنظیمات" to "com.android.settings",
            "settings" to "com.android.settings",
            "دوربین" to "com.android.camera",
            "camera" to "com.android.camera",
            "گالری" to "com.google.android.apps.photos",
            "photos" to "com.google.android.apps.photos",
            "یوتیوب" to "com.google.android.youtube",
            "youtube" to "com.google.android.youtube",
            "تلگرام" to "org.telegram.messenger",
            "telegram" to "org.telegram.messenger",
            "واتساپ" to "com.whatsapp",
            "whatsapp" to "com.whatsapp"
        )
        val match = apps.firstOrNull { message.contains(it.first, true) }
            ?: return "نام برنامه را مشخص کن؛ مثلاً بگو «تلگرام را باز کن»."
        val intent = packageManager.getLaunchIntentForPackage(match.second)
        return if (intent != null) {
            startActivity(intent)
            "در حال باز کردن ${match.first}."
        } else {
            "این برنامه روی گوشی پیدا نشد یا نام بستهٔ آن متفاوت است."
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage("RUMI", "تشخیص گفتار روی این دستگاه در دسترس نیست.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { addMessage("RUMI", "گوش می‌دم...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                addMessage("RUMI", "صدا دریافت نشد. دوباره امتحان کن.")
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = words?.firstOrNull()
                if (!spoken.isNullOrBlank()) handleMessage(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "با رومی صحبت کن")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rumi_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    private fun hideKeyboard() {
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(input.windowToken, 0)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
